const $=s=>document.querySelector(s),esc=s=>String(s??"").replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
const ss=sessionStorage; // session storage: login page appears every time the app is opened fresh
const S={token:ss.getItem("pcs_token"),roll:ss.getItem("pcs_roll"),ds:null,page:"dashboard",filter:"all",q:"",sel:null};
const NAV=[["training","ML Training"],["performance","Model Training"],["results","Screening Results"],["predict","Predict Cathode"],["export","Export Results"]];
const ic=p=>`<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">${p}</svg>`;
const ICON={dashboard:ic('<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/>'),training:ic('<path d="M4 21v-7M4 10V3M12 21v-9M12 8V3M20 21v-5M20 12V3M1 14h6M9 8h6M17 16h6"/>'),performance:ic('<path d="M3 3v18h18"/><path d="M7 15l4-4 3 3 5-6"/>'),results:ic('<path d="M9 11l3 3L22 4"/><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"/>'),export:ic('<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><path d="M7 10l5 5 5-5"/><path d="M12 15V3"/>')};
ICON.predict=ic('<path d="M9 3h6"/><path d="M10 3v6.5L4.5 19a1.5 1.5 0 0 0 1.3 2.2h12.4a1.5 1.5 0 0 0 1.3-2.2L14 9.5V3"/><path d="M7.5 15h9"/>');
const fmt=(v,d=3)=>v==null?"—":(typeof v==="number"?(Math.abs(v)<1e-3&&v!==0||Math.abs(v)>1e5?v.toExponential(2):+v.toFixed(d)):esc(v));
const badge=v=>`<span class="badge ${String(v).replace(/ /g,"")}">${v==="NOT AVAILABLE"?"N/A":v==="INCOMPLETE"?"NOT EVALUABLE":v}</span>`;
const toast=m=>{const t=$("#toast");t.textContent=m;t.style.display="block";setTimeout(()=>t.style.display="none",4000)};
async function api(p,o={}){o.headers={...(o.headers||{}),Authorization:"Bearer "+S.token};if(o.json){o.headers["Content-Type"]="application/json";o.body=JSON.stringify(o.json);o.method=o.method||"POST"}
 let r;try{r=await fetch("/api"+p,o)}catch(e){throw new Error("Cannot reach the server (API failure). Is the backend still running?")}
 if(r.status===401&&p!=="/login"){logout();throw new Error("Session expired – please log in again.")}
 if(!(r.headers.get("content-type")||"").includes("json"))return r;const j=await r.json();if(!r.ok)throw new Error(j.error||"Request failed");return j}
async function busy(msgs,fn){const b=$("#busy");b.classList.remove("hidden");let i=0;$("#busymsg").textContent=msgs[0];const t=setInterval(()=>$("#busymsg").textContent=msgs[Math.min(++i,msgs.length-1)],1800);
 try{return await fn()}finally{clearInterval(t);b.classList.add("hidden")}}
async function dl(path,name){await busy(["Preparing Excel..."],async()=>{const r=await api(path);if(r.blob){const u=URL.createObjectURL(await r.blob()),a=document.createElement("a");a.href=u;a.download=name;a.click()}})}
function logout(){ss.clear();S.token=null;S.ds=null;S.sel=null;show()}
$("#logout").onclick=logout;$("#mx").onclick=()=>$("#modal").classList.add("hidden");
$("#lf").onsubmit=async e=>{e.preventDefault();$("#lerr").textContent="";try{const j=await api("/login",{json:{roll_number:$("#roll").value,password:$("#pw").value}});S.token=j.token;S.roll=j.roll_number;ss.setItem("pcs_token",j.token);ss.setItem("pcs_roll",j.roll_number);$("#pw").value="";show()}catch(x){$("#lerr").textContent=x.message}};
async function show(){const ok=!!S.token;$("#login").classList.toggle("hidden",ok);$("#app").classList.toggle("hidden",!ok);if(!ok)return;$("#who").textContent="Roll No: "+S.roll;
 const id=ss.getItem("pcs_ds");if(id&&!S.ds){try{S.ds=await api("/datasets/"+id)}catch(e){ss.removeItem("pcs_ds")}}go(S.page||"dashboard")}
const backTo=()=>S.page==="results"||!S.ds||S.ds.status!=="screened"?"dashboard":"results";
const allowed=p=>!S.ds||p==="dashboard"||p==="training"||(p==="performance"?!!S.ds.train:(S.ds.status==="screened"&&!!S.ds.summary));
function go(p){if(!allowed(p))p=S.ds.train?"performance":"training";S.page=p;
 $("#nav").innerHTML=`<a class="${p==="dashboard"?"on":""}" onclick="go('dashboard')">${ICON.dashboard}Dashboard</a>`+(S.ds?`<div class="lbl" onclick="openFile(${S.ds.id})" title="Open this dataset in Excel">${esc(S.ds.filename)}</div>`+NAV.map(([k,l])=>allowed(k)?`<a class="${k===p?"on":""}" onclick="go('${k}')">${ICON[k]||""}${l}</a>`:`<a class="dis" title="Locked – finish the previous step first">${ICON[k]||""}${l}</a>`).join(""):"");
 $("#bar").innerHTML=p==="dashboard"?"":`<button class="btn sec sm" onclick="go(backTo())">← Back</button><span class="muted small">${S.ds?esc(S.ds.filename):""}</span>`;
 $("#main").innerHTML="";window.scrollTo(0,0);Promise.resolve(P[p]()).catch(e=>{$("#main").innerHTML=`<div class="note bad">${esc(e.message)}</div>`})}
async function openDs(id,page){S.ds=await api("/datasets/"+id);ss.setItem("pcs_ds",id);S.filter="all";S.q="";S.sel=null;go(page||(S.ds.status==="screened"?"results":"training"))}
const need=()=>S.ds?"":`<div class="card">No dataset open. Go to the <a href="#" onclick="go('dashboard');return false">Dashboard</a> and click OPEN on a dataset.</div>`;
const stat=(v,l,c="")=>`<div class="stat ${c}"><b>${v}</b><span>${l}</span></div>`;
const P={};
P.dashboard=async()=>{const d=await api("/dashboard"),t=d.totals;
 const card=x=>`<div class="ds ${S.ds&&S.ds.id===x.id?"cur":""}"><div><b class="dsname" onclick="openDs(${x.id})">${esc(x.filename)}</b><br><span class="muted small">${x.row_count} cathodes · Uploaded: ${x.upload_date} ${x.model?"· Model: "+x.model:""}</span><br>${x.status==="screened"?`PASS: <b>${x.pass}</b> &nbsp; FAIL: <b>${x.fail}</b>`:`<span class="badge NA">${x.status}</span> not screened yet`}</div>
 <div><button class="btn sm" onclick="openDs(${x.id})">OPEN</button> <button class="btn sm sec" ${x.status!=="screened"?"disabled":""} onclick="openDs(${x.id},'results')">RESULTS</button> <button class="btn sm sec" onclick="delDs(${x.id})">Delete</button></div></div>`;
 $("#main").innerHTML=`<h2>Welcome, ${esc(d.roll_number)}</h2><div class="grid g4">${stat(t.datasets,"Total datasets")}${stat(t.cathodes_screened,"Total cathodes screened")}${stat(t.pass,"Total PASS","p")}${stat(t.fail,"Total FAIL","f")}</div><p class="small muted">Totals count each distinct formula once, even if it appears in several rows or datasets.</p>
 <div class="drop" id="dz" style="padding:22px"><b style="font-size:16px">Upload New Dataset</b><br><span class="muted">Drop a CSV / Excel file here or click to browse (.csv .xlsx .xls) — one row per cathode</span><input type="file" id="fi" accept=".csv,.xlsx,.xls" class="hidden"></div>
 <h3 style="margin-top:18px">MY RECENT SCREENINGS</h3>${d.datasets.map(card).join("")||'<p class="muted">No datasets uploaded yet.</p>'}`;
 const dz=$("#dz"),fi=$("#fi");dz.onclick=()=>fi.click();dz.ondragover=e=>{e.preventDefault();dz.classList.add("over")};dz.ondragleave=()=>dz.classList.remove("over");dz.ondrop=e=>{e.preventDefault();dz.classList.remove("over");up(e.dataTransfer.files[0])};fi.onchange=()=>up(fi.files[0])};
window.delDs=async id=>{if(confirm("Delete this dataset and all its results?")){await api("/datasets/"+id,{method:"DELETE"});if(S.ds&&S.ds.id===id){S.ds=null;ss.removeItem("pcs_ds")}go("dashboard")}};
async function up(f){if(!f)return;const fd=new FormData();fd.append("file",f);try{const j=await busy(["Uploading dataset...","Analyzing dataset..."],()=>api("/datasets",{method:"POST",body:fd}));if(j.duplicate)toast("This dataset is already in your history – opened the existing copy.");await openDs(j.id,"training")}catch(e){toast(e.message)}}
const selc=(id,cols,val)=>`<select id="${id}"><option value="">— choose column —</option>${cols.map(c=>`<option ${c===val?"selected":""}>${esc(c)}</option>`).join("")}</select>`;
const NA='<span class="na">Not available</span>';
P.training=()=>{if(!S.ds)return $("#main").innerHTML=need();const a=S.ds.analysis,m=S.ds.train?.mapping||a.mapping,t=S.ds.train,miss=Object.entries(a.missing),inv=Object.entries(a.invalid_numeric),d=a.descriptors;
 const pick=(l,id)=>`<tr><td>${l}</td><td>${selc(id,a.columns,null)} <span class="na">Not detected – choose it</span></td></tr>`;
 const need_map=!m.formula||!m.target;
 $("#main").innerHTML=`<h2>ML Training &amp; Dataset Analysis</h2><div class="grid g4">${stat(esc(S.ds.filename).slice(0,22),"File")}${stat(a.rows,"Cathodes (rows)")}${stat(a.n_columns,"Columns")}</div>
 ${a.target_note?`<div class="note">${esc(a.target_note)}</div>`:""}${!m.ehull?'<div class="note bad">Ehull column is <b>not available</b> in this dataset – the Ehull criterion cannot be evaluated, so no cathode can receive a full PASS.</div>':""}
 ${need_map?`<div class="card"><h3>Select the missing columns</h3><table>${!m.formula?pick("Chemical formula","m_f"):""}${!m.target?pick("Target log10(k*)","m_t"):""}</table></div>`:""}
 <div class="card"><h3>Paper descriptors vs. your dataset</h3>
 <div class="tw"><table><thead><tr><th>Paper descriptor</th><th>Group</th><th>Dataset column</th><th>Status</th></tr></thead><tbody>${d.map(e=>`<tr><td>${esc(e.label)}</td><td>${e.group}</td><td>${e.column?esc(e.column):"—"}</td><td>${e.usable?'<span class="ok">Available</span>':`<span class="na">Not available</span> <span class="small muted">${e.present?"("+esc(e.reason)+")":""}</span>`}</td></tr>`).join("")}</tbody></table></div></div>
 ${miss.length?`<div class="card"><h3>Missing values</h3>${miss.map(([c,n])=>`${esc(c)}: ${n}`).join(" · ")}<p class="small muted">Filled with the training-fold median inside the Pipeline (no leakage).</p></div>`:""}
 ${inv.length?`<div class="card"><h3>Invalid numerical values</h3>${inv.map(([c,n])=>`${esc(c)}: ${n} non-numeric entries treated as missing`).join("<br>")}</div>`:""}
 <div class="card"><h3>Training</h3>
 ${t?`<div class="note ok"><b>Selected features (${t.features.length}${t.feature_selection?" of "+t.feature_selection.n_candidates:""}):</b> ${t.features.map(c=>`<span class="pill">${esc(c)}</span>`).join("")}</div>`:'<div class="note">Not trained yet.</div>'}
 <div style="max-width:320px;margin:14px 0 4px"><label style="font-weight:600">Model for training<select id="m_model" onchange="setModel(this.value)">${["SVR","ANN"].map(k=>`<option value="${k}"${k===(S.model||t?.primary||"SVR")?" selected":""}>${k==="SVR"?"SVR – Support Vector Regression":"ANN – Artificial Neural Network"}</option>`).join("")}</select></label></div>
 <button class="btn" onclick="runTrain()">${t?"Re-train":"Train"}</button></div>`};
window.setModel=v=>{S.model=v};
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
window.openFile=async id=>{try{const j=await api(`/datasets/${id}/open`,{method:"POST"});if(j&&j.opened){toast("Opening the dataset in Excel…");return}
  const r=await fetch(`/api/datasets/${id}/file`,{headers:{Authorization:"Bearer "+S.token}});if(!r.ok)throw new Error("Could not open the dataset file.");
  const b=await r.blob(),a=document.createElement("a");a.href=URL.createObjectURL(b);a.download=S.ds&&S.ds.id===id?S.ds.filename:"dataset";document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(a.href),4000);toast("Dataset downloaded – open it with Excel.")}
 catch(e){toast(e.message)}};
window.runTrain=async()=>{const v=id=>$("#"+id)?.value||null;const mp={formula:v("m_f"),target:v("m_t")};const mt=v("m_model")||S.model||"SVR";S.model=mt;
 try{await busy(["Preparing features...","Training "+mt+" model...","Selecting features...","Validating models...","Finalizing..."],()=>Promise.all([api(`/datasets/${S.ds.id}/train`,{json:{mapping:mp,model_type:mt}}),sleep(5000)]));await openDs(S.ds.id,"performance")}
 catch(e){toast(e.message);go("training");$("#main").insertAdjacentHTML("afterbegin",`<div class="note bad">${esc(e.message)}</div>`)}};
window.runScreen=async()=>{
 try{await busy(["Predicting cathodes...","Applying screening criteria...","Generating results..."],()=>Promise.all([api(`/datasets/${S.ds.id}/screen`,{method:"POST"}),sleep(5000)]));await openDs(S.ds.id,"results")}
 catch(e){toast(e.message)}};
function parity(p){
 const W=380,pad=40,all=p.y.concat(p.pred,p.y_train||[],p.pred_train||[]),lo=Math.min(...all),hi=Math.max(...all),sc=v=>pad+(v-lo)/(hi-lo)*(W-2*pad),tk=[0,1,2,3,4].map(i=>lo+(hi-lo)*i/4);
 const grid=tk.map(v=>`<line x1="${sc(v)}" x2="${sc(v)}" y1="${pad-10}" y2="${W-pad}" stroke="#eef2f6"/><line y1="${W-sc(v)}" y2="${W-sc(v)}" x1="${pad}" x2="${W-pad+10}" stroke="#eef2f6"/><text x="${sc(v)}" y="${W-pad+16}" text-anchor="middle" font-size="10" fill="#64748b">${v.toFixed(1)}</text><text x="${pad-6}" y="${W-sc(v)+3}" text-anchor="end" font-size="10" fill="#64748b">${v.toFixed(1)}</text>`).join("");
 const dots=(ys,ps,c,o,r)=>(ys||[]).map((y,i)=>`<circle cx="${sc(y)}" cy="${W-sc(ps[i])}" r="${r}" fill="${c}" opacity="${o}"/>`).join("");
 return `<svg viewBox="0 0 ${W} ${W}" style="width:100%;max-width:${W}px;background:#fff;border:1px solid var(--line);border-radius:10px">${grid}<line x1="${sc(lo)}" y1="${W-sc(lo)}" x2="${sc(hi)}" y2="${W-sc(hi)}" stroke="#c1121f" stroke-dasharray="5 4"/>${dots(p.y_train,p.pred_train,"#9db4c4",.55,3)}${dots(p.y,p.pred,"#0f8b8d",.9,4.5)}<text x="${W/2}" y="${W-6}" text-anchor="middle" font-size="11" fill="#0f2a43">experimental log10(k*)</text><text x="11" y="${W/2}" font-size="11" fill="#0f2a43" transform="rotate(-90 11 ${W/2})" text-anchor="middle">predicted log10(k*)</text></svg>
 <div class="lg"><span><i style="background:#0f8b8d"></i>Test set (40%, unseen)</span><span><i style="background:#9db4c4"></i>Training set (60%)</span><span>Dashed line = perfect prediction</span></div>`}

// ---------- correlation & covariance ----------
const relNum=v=>v==null?"—":(Math.abs(v)>=100?v.toFixed(0):Math.abs(v)>=10?v.toFixed(1):v.toFixed(2));
function relMatrix(st,mode){
 const M=mode==="corr"?st.corr:st.cov,nm=st.names,n=nm.length;let mx=1;
 if(mode==="cov"){mx=0;M.forEach((r,i)=>r.forEach((v,j)=>{if(i!==j&&v!=null)mx=Math.max(mx,Math.abs(v))}));mx=mx||1}
 const cell=(v,i,j)=>{if(v==null)return '<td class="mx-n">—</td>';const a=Math.min(1,Math.abs(v)/mx),
   bg=i===j?"rgba(100,116,139,.16)":(v>=0?`rgba(37,99,235,${(.08+.82*a).toFixed(2)})`:`rgba(220,38,38,${(.08+.82*a).toFixed(2)})`);
  return `<td style="background:${bg};color:${i!==j&&a>.55?"#fff":"#0f2a43"}" title="${esc(nm[i])} × ${esc(nm[j])}: ${v}">${mode==="corr"?v.toFixed(2):relNum(v)}</td>`};
 return `<div class="mx-wrap"><table class="mx"><thead><tr><th></th>${nm.map((c,j)=>`<th class="${j===n-1?"mx-t":""}"><span>${esc(c)}</span></th>`).join("")}</tr></thead><tbody>${M.map((row,i)=>`<tr><th class="mx-r ${i===n-1?"mx-t":""}">${esc(nm[i])}</th>${row.map((v,j)=>cell(v,i,j)).join("")}</tr>`).join("")}</tbody></table></div>`}
window.setRel=m=>{const st=S.ds.train.stats;$("#relbox").innerHTML=relMatrix(st,m);["corr","cov"].forEach(k=>$("#rt_"+k).classList.toggle("on",k===m))};
function relTable(t){const st=t.stats;if(!st)return "";
 const word=r=>{const a=Math.abs(r);return a>=.8?"very strong":a>=.6?"strong":a>=.4?"moderate":a>=.2?"weak":"very weak"};
 const ti=st.names.length-1,rel=st.names.slice(0,ti).map((c,i)=>({c,r:st.corr[i][ti]})).filter(x=>x.r!=null).sort((a,b)=>Math.abs(b.r)-Math.abs(a.r));
 return `<div><h4>How each descriptor relates to ${esc(st.target)}</h4>${rel.map(x=>`<div class="rrow"><span class="rn">${esc(x.c)}</span><div class="rt"><i class="mid"></i><div class="rv" style="${x.r>=0?"left":"right"}:50%;width:${Math.abs(x.r)*50}%;background:${x.r>=0?"#2563eb":"#dc2626"}"></div></div><span class="rr"><b>${x.r.toFixed(2)}</b> <span class="muted">${word(x.r)}</span></span></div>`).join("")}</div>`}
function relCard(t){
 const st=t.stats;
 if(!st)return '<div class="card"><h3>Correlation &amp; covariance</h3><div class="note">Click <b>Re-train</b> on the ML Training page once to see the correlation and covariance matrices.</div></div>';
 const ti=st.names.length-1;
 return `<div class="card"><div class="card-h"><div><h3>Correlation &amp; covariance</h3><p>Calculated on the ${st.n} training cathodes: ${ti} descriptors plus the target <b>${esc(st.target)}</b> (last row and column).</p></div><div class="rtabs"><button class="rtab on" id="rt_corr" onclick="setRel('corr')">Correlation</button><button class="rtab" id="rt_cov" onclick="setRel('cov')">Covariance</button></div></div>
  <div id="relbox">${relMatrix(st,"corr")}</div></div>`}

// ---------- NEW: feature-selection report (Model Training page) ----------
function fsReport(t){
 const fs=t.feature_selection;
 if(!fs)return '<div class="card"><h3>Feature selection</h3><div class="note">Click <b>Re-train</b> on the ML Training page once to run the feature selection.</div></div>';
 const v=fs.versus,o=v.original,n=v.selected,d=(a,b,f=3)=>{const x=b-a;return (x>0?"+":"")+x.toFixed(f)};
 const lab={};(t.shap||[]).forEach(x=>lab[x.feature]=x.label);
 const selgrid=`<div class="selgrid">${fs.selected.map((c,i)=>`<div class="selitem"><span class="si-n">${i+1}</span><div><b>${esc(c)}</b>${lab[c]&&lab[c]!==c?`<small>${esc(lab[c])}</small>`:""}</div></div>`).join("")}</div>`;
 return `<div class="card sel-card"><div class="card-h"><div><h3>Selected features <span class="pill">${fs.selected.length} of ${fs.n_candidates}</span></h3></div></div>
  <div class="grid g2" style="align-items:start"><div>${selgrid}</div>${relTable(t)}</div>
  ${(t.unavailable_descriptors||[]).length?`<p class="small"><b>Not available in the dataset:</b> <span class="na">${t.unavailable_descriptors.map(u=>esc(u.key)).join(", ")}</span></p>`:""}</div>
 <div class="card"><h3>Original model vs new model</h3><div class="tw"><table><thead><tr><th>Model</th><th>Features</th><th>Grouped-CV R²</th><th>Grouped-CV RMSE</th><th>Test R²</th><th>Test RMSE</th></tr></thead><tbody>
   <tr><td><b>${o.label}</b></td><td>${o.n_features}</td><td>${o.cv_r2.toFixed(3)}</td><td>${o.cv_rmse.toFixed(3)}</td><td>${o.test_r2.toFixed(3)}</td><td>${o.test_rmse.toFixed(3)}</td></tr>
   <tr class="sel-row"><td><b>${n.label}</b></td><td>${n.n_features}</td><td>${n.cv_r2.toFixed(3)}</td><td>${n.cv_rmse.toFixed(3)}</td><td><b>${n.test_r2.toFixed(3)}</b></td><td><b>${n.test_rmse.toFixed(3)}</b></td></tr>
   <tr><td class="muted">Change (new − original)</td><td class="muted">${n.n_features-o.n_features}</td><td class="muted">${d(o.cv_r2,n.cv_r2)}</td><td class="muted">${d(o.cv_rmse,n.cv_rmse)}</td><td class="muted">${d(o.test_r2,n.test_r2)}</td><td class="muted">${d(o.test_rmse,n.test_rmse)}</td></tr></tbody></table></div></div>`}

P.performance=()=>{if(!S.ds)return $("#main").innerHTML=need();const t=S.ds.train;const mt=(t&&(t.primary||t.model_type))||"SVR";if(!t)return $("#main").innerHTML='<div class="note">Train the models first (ML Training page).</div>';
 if(t.n_test==null||t.n_groups==null)return $("#main").innerHTML='<div class="note">This dataset was trained with an older version (no grouped split / feature selection). Open ML Training and click <b>Re-train</b> to update it.</div>';
 $("#main").innerHTML=`<h2>Model Training</h2>
 <div class="grid g4">${stat(t.n_train+" / "+t.n_test,"Train / test rows (60:40 by composition)")}</div>
 <div style="margin-top:16px">${fsReport(t)}</div>
 <div class="card"><h3>Model comparison on the selected features – scores on the unseen 40% testing set</h3><div class="tw"><table><thead><tr><th>Model</th><th>Test R²</th><th>Test MAE</th><th>Test RMSE</th><th>Train R²</th><th>Grouped-CV R² (train part)</th><th>Tuning</th><th>Best params</th></tr></thead><tbody>${t.comparison.map(m=>`<tr><td><b>${m.model}</b> ${m.model===mt?'<span class="badge PASS">primary</span>':""}</td><td><b>${fmt(m.R2)}</b></td><td>${fmt(m.MAE)}</td><td>${fmt(m.RMSE)}</td><td>${fmt(m.train_R2)}</td><td>${fmt(m.cv_R2)} ± ${fmt(m.cv_R2_std,2)}</td><td class="small">${esc(m.search)}</td><td class="small">${esc(JSON.stringify(m.params))}</td></tr>`).join("")}</tbody></table></div></div>
 ${relCard(t)}
 <div class="grid g2" style="align-items:center"><div class="card"><h3>${mt}: predicted vs experimental</h3>${parity(t.parity)}</div><div style="display:flex;justify-content:center"><button class="btn" style="padding:20px 44px;font-size:1.25rem" onclick="runScreen()">Train using ${mt}</button></div></div>`};
// ---- Screening Results tab ----

// ---------- Criteria card ----------
function critCard(title,limit,p,f,n){
  const tot=p+f+n,ev=p+f;
  if(!ev)return `<div class="crit"><div class="crit-t">${title}</div><div class="crit-l">${limit}</div><div class="crit-na">Not available</div><div class="small muted">This criterion could not be evaluated for this dataset.</div></div>`;
  const pct=Math.round(p/ev*100),w=v=>(100*v/tot).toFixed(2)+"%";
  return `<div class="crit"><div class="crit-t">${title}</div><div class="crit-l">${limit}</div>
   <div class="crit-v">${pct}<small>%</small><em>PASS RATE</em></div>
   <div class="seg"><i style="width:${w(p)};background:var(--green)"></i><i style="width:${w(f)};background:var(--red)"></i>${n?`<i style="width:${w(n)};background:var(--amber)"></i>`:""}</div>
   <div class="crit-n"><span><i class="d g"></i><b>${p}</b> pass</span><span><i class="d r"></i><b>${f}</b> fail</span>${n?`<span><i class="d a"></i><b>${n}</b> N/A</span>`:""}</div></div>`;
}

// ---------- log10(k*) card ----------
async function lk(){
  const el=$("#lkcard");if(!el)return;
  const r=await api(`/datasets/${S.ds.id}/results?filter=all&q=`),v=r.map(x=>x.predicted_log_kstar).filter(x=>x!=null).sort((a,b)=>a-b);
  if(!v.length){el.innerHTML='<div class="crit-t">Predicted log10(k*)</div><div class="crit-na">No data</div>';return}
  const n=v.length,mx=v[n-1],above=v.filter(t=>t>=-6.4).length,below=n-above,w=c=>(100*c/n).toFixed(2)+"%";
  el.innerHTML=`<div class="crit-t">Predicted log10(k*)</div><div class="crit-l">Surface exchange coefficient, log scale</div>
   <div class="crit-v">${fmt(mx,2)}<em>HIGHEST</em></div>
   <div class="seg"><i style="width:${w(above)};background:var(--green)"></i><i style="width:${w(below)};background:var(--red)"></i></div>
   <div class="crit-n"><span><i class="d g"></i><b>${above}</b> ≥ −6.40</span><span><i class="d r"></i><b>${below}</b> below</span></div>`;
}

// ---------- Rankings list ----------


P.results=async()=>{
  S.filter="all";
  if(!S.ds)return $("#main").innerHTML=need();
  const s=S.ds.summary;
  if(!s)return $("#main").innerHTML='<div class="note">Not screened yet – open <a href="#" onclick="go(\'performance\');return false">Model Training</a> and press <b>Train using '+((S.ds.train&&(S.ds.train.primary||S.ds.train.model_type))||"SVR")+'</b>.</div>';
  $("#main").innerHTML=`<div class="ph"><div><h2>Screening Results</h2><div class="sub">${esc(S.ds.filename)} · ${s.total} cathodes screened</div></div><button class="btn sec" onclick="go('export')">Export results</button></div>
   <div class="grid g4">${stat(s.total,"Total cathodes")}${stat(s.PASS,"PASS","p")}${stat(s.FAIL,"FAIL","f")}${s.INCOMPLETE?stat(s.INCOMPLETE,"Not evaluable","n"):""}${stat(s.pass_pct+"%","Pass rate")}</div>
   ${s.duplicates_merged?`<p class="small muted">${s.duplicates_merged} rows with a repeated formula were merged – each formula is counted once.</p>`:""}
   ${!s.ehull_available?'<div class="note bad">Ehull is <span class="na">not available</span> in this dataset, so the Ehull criterion could not be evaluated.</div>':""}
   <div class="sec-t">Screening criteria</div>
   <div class="grid g4c">${critCard("Applicability domain","Mahalanobis distance inside the training domain",s.inside_ad,s.outside_ad,0)}${critCard("Stability: Ehull","Pass if Ehull ≤ 57 meV/atom",s.ehull_pass,s.ehull_fail,s.ehull_not_available)}${critCard("ORR activity","Pass if predicted log10(k*) ≥ −6.40 (LSC benchmark)",s.orr_pass,s.orr_fail,0)}<div class="crit" id="lkcard"><div class="crit-t">Predicted log10(k*)</div><div class="crit-l">Surface exchange coefficient, log scale</div><p class="small muted">Loading…</p></div></div>
   <div class="sec-t">Cathode ranking</div>
   <div class="card flush">
        <div class="tool"><input id="q" placeholder="Search formula…" value="${esc(S.q)}"><select id="rf" style="max-width:300px;margin:0"><option value="all">Results of all cathodes</option><option value="test">Results of test cathodes (40%)</option><option value="train">Results of training cathodes (60%)</option></select></div>
    <div class="tw"><table><thead><tr><th>Rank</th><th>Cathode / Formula</th><th>Predicted log10(k*)</th><th>Final</th></tr></thead><tbody id="tb"></tbody></table></div>
    <p class="small muted" id="cnt" style="padding:10px 20px;margin:0"></p>
   </div>
`;
  $("#rf").onchange=e=>{S.filter=e.target.value;loadRes()};
  let tm;$("#q").oninput=e=>{S.q=e.target.value;clearTimeout(tm);tm=setTimeout(loadRes,250)};
  loadRes();lk().catch(()=>{});
};
async function loadRes(){
  const r=await api(`/datasets/${S.ds.id}/results?filter=${S.filter}&q=${encodeURIComponent(S.q)}`);
  document.querySelectorAll(".chip").forEach(c=>c.classList.toggle("on",c.dataset.k===S.filter));
  $("#tb").innerHTML=r.map(x=>`<tr class="click t-${x.tier}" onclick="detail(${x.id})"><td><b>#${x.rank}</b></td><td><a class="flink">${esc(x.formula)}</a></td><td>${fmt(x.predicted_log_kstar,2)}</td><td>${badge(x.final_result)}</td></tr>`).join("");
  $("#cnt").textContent=r.length+" cathodes shown · click a name for details";
}

const dhtml=x=>{
 const d=x.detail,t=d.thresholds,f=x.final_result,p=x.orr_value,e=x.ehull,k=x.predicted_kstar,
  orrM=p-t.orr,ehM=e==null?null:t.ehull-e,adR=x.mahalanobis_distance/t.ad,dist=fmt(x.mahalanobis_distance,2),fails=[];
 if(x.ad_result==="FAIL")fails.push(`It lies <b>outside the applicability domain</b> – its distance of ${dist} is above the limit of ${fmt(t.ad,2)}, so the model’s prediction for it is less reliable.`);
 if(x.ehull_result==="FAIL")fails.push(`Its <b>Ehull</b> of ${fmt(e,1)} meV/atom is ${fmt(-ehM,1)} above the ${t.ehull} meV/atom limit, so it is not stable enough.`);
 if(x.orr_result==="FAIL")fails.push(`Its predicted <b>log10(k*)</b> of ${fmt(p,2)} is ${fmt(-orrM,2)} below the ${t.orr} benchmark, so it is not active enough.`);
 const expl=f==="PASS"
  ?`<div class="expl good"><b>${esc(x.formula)}</b> passes every screening check.<ul><li>Applicability domain: inside – distance ${dist} is within the limit of ${fmt(t.ad,2)}.</li><li>Stability: Ehull of ${fmt(e,1)} meV/atom is within the ${t.ehull} limit (${fmt(ehM,1)} below it).</li><li>Activity: predicted log10(k*) of ${fmt(p,2)} is ${fmt(orrM,2)} above the ${t.orr} benchmark.</li></ul></div>`
  :f==="FAIL"
  ?`<div class="expl bad"><b>${esc(x.formula)}</b> failed screening. <b>Why it failed:</b><ul>${fails.map(m=>`<li>${m}</li>`).join("")}</ul></div>`
  :`<div class="expl"><b>${esc(x.formula)}</b> could not be fully evaluated. ${d.not_available.map(esc).join(" ")}${fails.length?`<ul>${fails.map(m=>`<li>${m}</li>`).join("")}</ul>`:""}</div>`;
 const chk=(ti,res,val,req,margin,pct)=>`<div class="chk ${String(res).replace(/ /g,"")}"><div class="t"><span>${ti}</span>${badge(res)}</div><div class="v">${val}</div><div class="r">Requirement: ${req}</div><div class="r">${margin}</div>${pct!=null?`<div class="gauge"><i style="width:${Math.min(100,pct)}%;background:${res==="PASS"?"var(--pass)":"var(--fail)"}"></i></div>`:""}</div>`;
 return `<div class="dh"><div><h2>${esc(x.formula)}</h2><div class="sub">Screening result</div></div><div class="verdict ${f}">${f==="INCOMPLETE"?"NOT EVALUABLE":f}</div></div>
 ${expl}
 <h3>Screening values</h3><div class="checks">${chk("Applicability domain",x.ad_result,x.applicability_domain+" · distance "+dist,`distance ≤ ${fmt(t.ad,2)}`,x.ad_result==="PASS"?"Prediction is reliable":"Prediction is less reliable",Math.min(100,adR*100))}${chk("Ehull (stability)",x.ehull_result,e==null?"—":fmt(e,1)+" meV/atom",`≤ ${t.ehull} meV/atom`,e==null?"Not available in dataset":(ehM>=0?`${fmt(ehM,1)} below the limit`:`${fmt(-ehM,1)} above the limit`),e==null?null:e/t.ehull*100)}${chk("ORR activity",x.orr_result,"log10(k*) "+fmt(p,2),`≥ ${t.orr} (LSC benchmark)`,(orrM>=0?`${fmt(orrM,2)} above the benchmark`:`${fmt(-orrM,2)} below the benchmark`)+` · k* = ${fmt(k)} cm/s`,Math.max(0,Math.min(100,100+orrM*50)))}</div>`};
window.detail=async id=>{const x=await api(`/datasets/${S.ds.id}/results/${id}`);S.sel=x;$("#mbody").innerHTML=dhtml(x);$("#modal").classList.remove("hidden")};
// ---------- Predict a single cathode (uses the saved model + saved training data) ----------
const checksHtml=o=>{
 const t=o.thresholds,p=o.pred_log,e=o.ehull,orrM=p-t.orr,ehM=e==null?null:t.ehull-e,adR=o.dist/t.ad;
 const chk=(ti,res,val,req,margin,pct)=>`<div class="chk ${String(res).replace(/ /g,"")}"><div class="t"><span>${ti}</span>${badge(res)}</div><div class="v">${val}</div><div class="r">Requirement: ${req}</div><div class="r">${margin}</div>${pct!=null?`<div class="gauge"><i style="width:${Math.min(100,pct)}%;background:${res==="PASS"?"var(--pass)":"var(--fail)"}"></i></div>`:""}</div>`;
 return `<div class="checks one">${chk("Applicability domain",o.ad_result,(o.ad==="INSIDE"?"INSIDE":"OUTSIDE")+" · distance "+fmt(o.dist,2),`distance ≤ ${fmt(t.ad,2)}`,o.ad_result==="PASS"?"Prediction is reliable":"Prediction is less reliable",Math.min(100,adR*100))}${chk("Ehull (stability)",o.ehull_result,e==null?"not entered":fmt(e,1)+" meV/atom",`≤ ${t.ehull} meV/atom`,e==null?"Enter Ehull to check stability":(ehM>=0?`${fmt(ehM,1)} below the limit`:`${fmt(-ehM,1)} above the limit`),e==null?null:e/t.ehull*100)}${chk("ORR activity",o.orr_result,"log10(k*) "+fmt(p,2),`≥ ${t.orr} (LSC benchmark)`,orrM>=0?`${fmt(orrM,2)} above the benchmark`:`${fmt(-orrM,2)} below the benchmark`,Math.max(0,Math.min(100,100+orrM*50)))}</div>`};
const whyHtml=o=>{
 const t=o.thresholds,f=o.final,p=o.pred_log,e=o.ehull,orrM=p-t.orr,ehM=e==null?null:t.ehull-e,dist=fmt(o.dist,2),fails=[];
 if(o.ad_result==="FAIL")fails.push(`It lies <b>outside the applicability domain</b> – its distance of ${dist} is above the limit of ${fmt(t.ad,2)}, so the model’s prediction for it is less reliable.`);
 if(o.ehull_result==="FAIL")fails.push(`Its <b>Ehull</b> of ${fmt(e,1)} meV/atom is ${fmt(-ehM,1)} above the ${t.ehull} meV/atom limit, so it is not stable enough.`);
 if(o.orr_result==="FAIL")fails.push(`Its predicted <b>log10(k*)</b> of ${fmt(p,2)} is ${fmt(-orrM,2)} below the ${t.orr} benchmark, so it is not active enough.`);
 if(f==="PASS")return `<div class="expl good"><b>Result: PASS – it meets every screening condition.</b><ul><li>Applicability domain: inside – distance ${dist} is within the limit of ${fmt(t.ad,2)}.</li><li>Stability: Ehull of ${fmt(e,1)} meV/atom is within the ${t.ehull} limit (${fmt(ehM,1)} below it).</li><li>Activity: predicted log10(k*) of ${fmt(p,2)} is ${fmt(orrM,2)} above the ${t.orr} benchmark.</li></ul></div>`;
 if(f==="FAIL")return `<div class="expl bad"><b>Result: FAIL – reason:</b><ul>${fails.map(m=>`<li>${m}</li>`).join("")}</ul></div>`;
 return `<div class="expl"><b>Result: could not be fully evaluated.</b> ${(o.not_available||[]).map(esc).join(" ")}${fails.length?`<ul>${fails.map(m=>`<li>${m}</li>`).join("")}</ul>`:"<br>Everything that could be checked passed."}</div>`};
const cmpHtml=c=>{
 const out=c.ranges.filter(r=>!r.inside);
 return `<h3 style="margin-top:16px">Compared with the saved training data</h3><p class="small muted">The model was trained on ${c.n_training} cathodes. The values you entered are compared with that saved data:</p>
  ${out.length?`<div class="note"><b>${out.length} of ${c.ranges.length} descriptors</b> lie outside the range seen in training, so the prediction is an extrapolation: ${out.map(r=>`${esc(r.feature)} (${fmt(r.value,3)}; training range ${fmt(r.min,3)} to ${fmt(r.max,3)})`).join(", ")}.</div>`:'<div class="note ok">All entered descriptors lie inside the range of the training data.</div>'}
  <div class="tw"><table><thead><tr><th>Most similar training cathodes</th><th>Distance</th><th>Experimental log10(k*)</th></tr></thead><tbody>${c.nearest.map(n=>`<tr><td><b>${esc(n.formula)}</b></td><td>${fmt(n.distance,2)}</td><td>${fmt(n.log_k,2)}</td></tr>`).join("")}</tbody></table></div>`};
const predHtml=o=>`<div class="card pres"><div class="pv ${o.final}"><div><div class="pv-s">${esc(o.formula)}</div><div class="pv-n">${o.final==="INCOMPLETE"?"NOT EVALUABLE":o.final}</div></div><div class="pv-r"><div class="pv-k">${fmt(o.pred_log,2)}</div><div class="pv-s">predicted log10(k*)</div><div class="pv-s">k* = ${fmt(o.pred_k)} cm/s</div></div></div>
  ${whyHtml(o)}<h3>Screening values</h3>${checksHtml(o)}
  ${o.imputed.length?`<p class="small muted">${o.imputed.length} descriptor value(s) were left blank and filled with the training median: ${o.imputed.map(esc).join(", ")}.</p>`:""}
  ${cmpHtml(o.compare)}
  <p class="small muted" style="margin:10px 0 0">Predicted by the saved ${esc(o.model.name)} model (trained on ${o.model.trained_on} cathodes).</p></div>`;
P.predict=()=>{
 if(!S.ds)return $("#main").innerHTML=need();const t=S.ds.train;
 if(!t)return $("#main").innerHTML='<div class="note">Train the models first – open <a href="#" onclick="go(\'training\');return false">ML Training</a>. The trained model and training data are saved automatically and used on this page.</div>';
 const lab={};(t.shap||[]).forEach(x=>lab[x.feature]=x.label);const st=t.feature_stats||{};
 $("#main").innerHTML=`<h2>Predict a Single Cathode</h2>
  <div class="pred-grid"><div class="card"><h3>Descriptor values</h3><p class="small muted">${t.features.length} descriptors selected by the feature selection (the only ones the model uses). Blank values are filled with the training median.</p>
   <label>Cathode name / formula (optional)<input id="pf_name" placeholder="e.g. La0.6Sr0.4CoO3" maxlength="60"></label>
   <div class="fgrid">${t.features.map(c=>{const s=st[c]||{};return `<label class="fld"><span class="fl-k">${esc(c)}</span><span class="fl-l">${esc(lab[c]||c)}</span><input type="number" step="any" data-f="${esc(c)}" placeholder="${s.median!=null?"e.g. "+fmt(s.median,3):"value"}"><span class="fl-h">${s.min!=null?`training range ${fmt(s.min,3)} to ${fmt(s.max,3)}`:""}</span></label>`}).join("")}</div>
   <h3 style="margin-top:18px">Stability</h3>
   <label class="fld" style="max-width:340px"><span class="fl-k">Ehull</span><span class="fl-l">Energy above hull (meV/atom) – needed for a full PASS / FAIL</span><input type="number" step="any" id="pf_eh" placeholder="e.g. 30"><span class="fl-h">Limit: ≤ 57 meV/atom</span></label>
   <div style="margin-top:18px;display:flex;gap:10px;flex-wrap:wrap"><button class="btn" id="pbtn" onclick="runPredict()">Predict</button><button class="btn sec" onclick="fillPred()">Fill with typical values</button><button class="btn sec" onclick="clearPred()">Clear</button></div></div>
  <div id="predres" class="pred-res"><div class="card pres empty"><div class="ph-ico">⬡</div><b>Result appears here</b><p class="small muted">Enter the values on the left and press <b>Predict</b>.</p></div></div></div>`;
 document.querySelectorAll("[data-f],#pf_eh,#pf_name").forEach(i=>i.addEventListener("keydown",e=>{if(e.key==="Enter")runPredict()}));
};
window.fillPred=()=>{const st=S.ds.train.feature_stats||{};document.querySelectorAll("[data-f]").forEach(i=>{const s=st[i.dataset.f];if(s&&s.median!=null)i.value=+s.median.toPrecision(5)})};
window.clearPred=()=>{document.querySelectorAll("[data-f],#pf_eh,#pf_name").forEach(i=>i.value="");$("#predres").innerHTML='<div class="card pres empty"><div class="ph-ico">⬡</div><b>Result appears here</b><p class="small muted">Enter the values on the left and press <b>Predict</b>.</p></div>'};
window.runPredict=async()=>{
 const values={};document.querySelectorAll("[data-f]").forEach(i=>{if(i.value.trim()!=="")values[i.dataset.f]=i.value});
 if(!Object.keys(values).length)return toast("Enter at least one descriptor value.");
 const b=$("#pbtn");b.disabled=true;b.textContent="Predicting…";
 try{const o=await api(`/datasets/${S.ds.id}/predict`,{json:{values,ehull:$("#pf_eh").value,formula:$("#pf_name").value}});$("#predres").innerHTML=predHtml(o)}
 catch(e){toast(e.message);$("#predres").innerHTML=`<div class="note bad">${esc(e.message)}</div>`}
 finally{b.disabled=false;b.textContent="Predict"}};

P.export=()=>{if(!S.ds)return $("#main").innerHTML=need();const s=S.ds.summary;if(!s)return $("#main").innerHTML='<div class="note">Run the screening first (Model Training page → the screening button).</div>';const n=S.ds.filename.replace(/\.[^.]+$/,"");
 $("#main").innerHTML=`<h2>Export Results</h2><div class="card"><p>All files are sorted by <b>rank</b> (closest to passing first); Excel rows are coloured <span style="background:#C6EFCE;padding:0 6px">green</span> / <span style="background:#FFE0B2;padding:0 6px">orange</span> / <span style="background:#F8C9C9;padding:0 6px">red</span>.</p>
 <p>Complete workbook sheets: <b>Screening Results</b> (${s.total}), <b>PASS Cathodes</b> (${s.PASS}), <b>FAIL Cathodes</b> (${s.FAIL}), Notes.</p>${s.PASS===0?'<div class="note">No cathode has a full PASS, so the PASS file will contain an empty sheet.</div>':""}
 <p><button class="btn" onclick="dl('/datasets/${S.ds.id}/export/all','${n}_all.xlsx')">Download Complete Results Excel</button> <button class="btn" onclick="dl('/datasets/${S.ds.id}/export/pass','${n}_PASS.xlsx')">Download PASS Cathodes Excel</button> <button class="btn sec" onclick="dl('/datasets/${S.ds.id}/export/fail','${n}_FAIL.xlsx')">Download FAIL Cathodes Excel</button> <button class="btn sec" onclick="dl('/datasets/${S.ds.id}/export/csv','${n}_results.csv')">Download Results CSV</button></p></div>`};
show();